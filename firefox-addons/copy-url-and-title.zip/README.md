# copy-url-and-title

A very small Firefox addon that will copy the current page title and URL, and format via Markdown in useful (to me) ways.
